import { Router, type IRouter } from "express";
import adminRouter from "./admin";
import healthRouter from "./health";
import supportRouter from "./support";

const router: IRouter = Router();

router.use(healthRouter);
router.use(adminRouter);
router.use(supportRouter);

export default router;
