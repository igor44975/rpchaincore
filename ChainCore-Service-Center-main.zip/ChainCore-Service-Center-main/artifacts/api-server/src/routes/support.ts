import { desc } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { db, supportRequestsTable, type SupportRequest } from "@workspace/db";
import { requireAdmin } from "./admin";

const router: IRouter = Router();
const maxServiceLength = 120;
const maxWalletLength = 120;
const maxComplaintLength = 5000;

function readText(value: unknown, maxLength: number) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, maxLength);
}

function handleDatabaseError(error: unknown, _request: Request, response: Response, next: NextFunction) {
  next(error);
}

async function sendTelegramNotification(request: Request, supportRequest: SupportRequest) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!botToken || !chatId) {
    request.log.warn("Telegram notification is not configured.");
    return;
  }

  const message = [
    "New ChainCore support complaint",
    "",
    `Service: ${supportRequest.service}`,
    `Wallet: ${supportRequest.wallet ?? "Not selected"}`,
    `Submitted: ${supportRequest.createdAt.toISOString()}`,
    "",
    "Complaint:",
    supportRequest.complaint.slice(0, 3500),
  ].join("\n");
  const copyText = supportRequest.complaint.slice(0, 256);

  const telegramResponse = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
      disable_web_page_preview: true,
      reply_markup: {
        inline_keyboard: [[{
          text: supportRequest.complaint.length > 256 ? "Copy first 256 characters" : "Copy complaint",
          copy_text: { text: copyText },
        }]],
      },
    }),
  });

  if (!telegramResponse.ok) {
    throw new Error(`Telegram returned HTTP ${telegramResponse.status}.`);
  }
}

router.post("/support-requests", async (request, response, next) => {
  const service = readText(request.body?.service, maxServiceLength);
  const wallet = readText(request.body?.wallet, maxWalletLength) || null;
  const complaint = readText(request.body?.complaint, maxComplaintLength);

  if (!service || !complaint) {
    response.status(400).json({ error: "A service and complaint are required." });
    return;
  }

  try {
    const [created] = await db
      .insert(supportRequestsTable)
      .values({ service, wallet, complaint })
      .returning({
        id: supportRequestsTable.id,
        service: supportRequestsTable.service,
        wallet: supportRequestsTable.wallet,
        complaint: supportRequestsTable.complaint,
        status: supportRequestsTable.status,
        createdAt: supportRequestsTable.createdAt,
      });

    try {
      await sendTelegramNotification(request, created);
    } catch (error) {
      request.log.warn({ err: error }, "Support complaint saved, but Telegram notification failed.");
    }

    response.status(201).json({ request: created });
  } catch (error) {
    handleDatabaseError(error, request, response, next);
  }
});

router.get("/admin/support-requests", requireAdmin, async (request, response, next) => {
  try {
    const requests = await db
      .select({
        id: supportRequestsTable.id,
        service: supportRequestsTable.service,
        wallet: supportRequestsTable.wallet,
        complaint: supportRequestsTable.complaint,
        status: supportRequestsTable.status,
        createdAt: supportRequestsTable.createdAt,
      })
      .from(supportRequestsTable)
      .orderBy(desc(supportRequestsTable.createdAt));

    response.json({ requests });
  } catch (error) {
    handleDatabaseError(error, request, response, next);
  }
});

export default router;