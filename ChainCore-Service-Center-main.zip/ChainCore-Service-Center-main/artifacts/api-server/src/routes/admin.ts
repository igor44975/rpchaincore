import { createHmac, timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type NextFunction, type Request, type Response } from "express";

const router: IRouter = Router();
const sessionCookieName = "cc_admin_session";
const sessionLifetimeSeconds = 8 * 60 * 60;

type AdminSession = {
  role: "admin";
  expiresAt: number;
};

function getCookie(request: Request, name: string) {
  const cookies = request.headers.cookie?.split(";") ?? [];
  const entry = cookies.find((cookie) => cookie.trim().startsWith(`${name}=`));
  return entry ? decodeURIComponent(entry.trim().slice(name.length + 1)) : undefined;
}

function encode(value: string) {
  return Buffer.from(value).toString("base64url");
}

function decode(value: string) {
  return Buffer.from(value, "base64url").toString("utf8");
}

function sign(payload: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret) return undefined;
  return createHmac("sha256", secret).update(payload).digest("base64url");
}

function passwordsMatch(actual: string, expected: string) {
  const actualBuffer = Buffer.from(actual);
  const expectedBuffer = Buffer.from(expected);
  return (
    actualBuffer.length === expectedBuffer.length &&
    timingSafeEqual(actualBuffer, expectedBuffer)
  );
}

function readSession(request: Request): AdminSession | undefined {
  const cookie = getCookie(request, sessionCookieName);
  if (!cookie) return undefined;

  const [encodedPayload, signature] = cookie.split(".");
  if (!encodedPayload || !signature || sign(encodedPayload) !== signature) {
    return undefined;
  }

  try {
    const session = JSON.parse(decode(encodedPayload)) as AdminSession;
    if (
      session.role !== "admin" ||
      !Number.isFinite(session.expiresAt) ||
      session.expiresAt <= Date.now()
    ) {
      return undefined;
    }
    return session;
  } catch {
    return undefined;
  }
}

export function requireAdmin(request: Request, response: Response, next: NextFunction) {
  if (!readSession(request)) {
    response.status(401).json({ error: "Admin authentication required." });
    return;
  }
  next();
}

function setSessionCookie(response: Response, session: AdminSession) {
  const payload = encode(JSON.stringify(session));
  const signature = sign(payload);
  if (!signature) return;

  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  response.setHeader(
    "Set-Cookie",
    `${sessionCookieName}=${encodeURIComponent(`${payload}.${signature}`)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${sessionLifetimeSeconds}${secure}`,
  );
}

router.post("/admin/login", (request, response) => {
  const password = process.env.ADMIN_DASHBOARD_PASSWORD;
  const sessionSecret = process.env.SESSION_SECRET;

  if (!password || !sessionSecret) {
    response.status(503).json({ error: "Admin access is not configured yet." });
    return;
  }

  if (
    typeof request.body?.password !== "string" ||
    !passwordsMatch(request.body.password, password)
  ) {
    response.status(401).json({ error: "Incorrect password." });
    return;
  }

  const session: AdminSession = {
    role: "admin",
    expiresAt: Date.now() + sessionLifetimeSeconds * 1000,
  };
  setSessionCookie(response, session);
  response.json({ authenticated: true, role: session.role });
});

router.get("/admin/session", (request, response) => {
  const session = readSession(request);
  if (!session) {
    response.status(401).json({ authenticated: false });
    return;
  }

  response.json({
    authenticated: true,
    role: session.role,
    expiresAt: session.expiresAt,
  });
});

router.post("/admin/logout", (_request, response) => {
  response.setHeader(
    "Set-Cookie",
    `${sessionCookieName}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`,
  );
  response.status(204).end();
});

export default router;