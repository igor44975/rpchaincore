import { useEffect, useState, type FormEvent } from "react";
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  Copy,
  Inbox,
  KeyRound,
  LockKeyhole,
  LogOut,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";

type AdminSession = {
  authenticated: boolean;
  role: "admin";
  expiresAt?: number;
};

type SupportRequest = {
  id: number;
  service: string;
  wallet: string | null;
  complaint: string;
  status: string;
  createdAt: string;
};

const apiBase = "/api/admin";

async function readResponse(response: Response) {
  const body = (await response.json().catch(() => ({}))) as { error?: string };
  if (!response.ok) throw new Error(body.error || "The admin service is unavailable.");
  return body;
}

function formatRequestDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Date unavailable"
    : date.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function AdminLogo() {
  return (
    <span className="admin-logo">
      <span className="admin-logo-mark">CC</span>
      <span>Chain<i>Core</i></span>
    </span>
  );
}

function AdminLogin({
  onAuthenticated,
}: {
  onAuthenticated: (session: AdminSession) => void;
}) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError("");

    try {
      const response = await fetch(`${apiBase}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ password }),
      });
      const session = (await readResponse(response)) as AdminSession;
      onAuthenticated(session);
      setPassword("");
    } catch (caughtError) {
      setError(caughtError instanceof Error ? caughtError.message : "Unable to sign in.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="admin-page admin-login-page">
      <div className="admin-login-orb admin-login-orb-one" />
      <div className="admin-login-orb admin-login-orb-two" />
      <section className="admin-login-card" aria-labelledby="admin-login-title">
        <a className="admin-home-link" href="/">
          <AdminLogo />
        </a>
        <div className="admin-lock-icon">
          <LockKeyhole size={22} />
        </div>
        <span className="admin-eyebrow">Private workspace</span>
        <h1 id="admin-login-title">Owner and investor access.</h1>
        <p className="admin-login-copy">
          Enter the dashboard password to review the ChainCore service center.
          This area is not part of the public support flow.
        </p>
        <form className="admin-login-form" onSubmit={submit}>
          <label className="admin-label" htmlFor="admin-password">Dashboard password</label>
          <div className="admin-password-field">
            <KeyRound size={16} />
            <input
              id="admin-password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Enter your password"
              required
              data-testid="input-admin-password"
            />
          </div>
          {error && <p className="admin-error" role="alert">{error}</p>}
          <button className="admin-submit-button" type="submit" disabled={submitting}>
            {submitting ? "Checking access…" : "Enter dashboard"}
            {!submitting && <ArrowRight size={16} />}
          </button>
        </form>
        <p className="admin-safety-note">
          <ShieldCheck size={14} /> Access is checked on the server and expires automatically.
        </p>
        <a className="admin-back-link" href="/">Return to public service center</a>
      </section>
    </main>
  );
}

function AdminDashboard({
  session,
  onLogout,
}: {
  session: AdminSession;
  onLogout: () => void;
}) {
  const [requests, setRequests] = useState<SupportRequest[]>([]);
  const [requestsLoading, setRequestsLoading] = useState(true);
  const [requestsError, setRequestsError] = useState("");
  const [copiedRequestId, setCopiedRequestId] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    setRequestsLoading(true);
    setRequestsError("");

    fetch(`${apiBase}/support-requests`, { credentials: "include" })
      .then(async (response) => {
        const body = (await readResponse(response)) as { requests?: SupportRequest[] };
        return Array.isArray(body.requests) ? body.requests : [];
      })
      .then((nextRequests) => {
        if (active) setRequests(nextRequests);
      })
      .catch((caughtError) => {
        if (active) {
          setRequestsError(caughtError instanceof Error ? caughtError.message : "Unable to load support complaints.");
        }
      })
      .finally(() => {
        if (active) setRequestsLoading(false);
      });

    return () => {
      active = false;
    };
  }, [session]);

  async function copyComplaint(request: SupportRequest) {
    try {
      await navigator.clipboard.writeText(request.complaint);
      setCopiedRequestId(request.id);
      window.setTimeout(() => setCopiedRequestId((currentId) => currentId === request.id ? null : currentId), 1800);
    } catch {
      setRequestsError("Copy is unavailable in this browser. Select the complaint text manually.");
    }
  }

  const dashboardItems = [
    { icon: CheckCircle2, label: "Public intake", value: "Online", detail: "Service flow available", tone: "green" },
    { icon: Activity, label: "Market feed", value: "Connected", detail: "CoinGecko price data", tone: "blue" },
    { icon: Sparkles, label: "Service coverage", value: "21", detail: "Support categories", tone: "violet" },
    { icon: ShieldCheck, label: "Access policy", value: "Enforced", detail: "Password + signed session", tone: "amber" },
  ];

  return (
    <main className="admin-page admin-dashboard-page">
      <header className="admin-topbar">
        <a className="admin-home-link" href="/"><AdminLogo /></a>
        <div className="admin-topbar-actions">
          <span className="admin-session-pill"><span /> Owner / investor</span>
          <button className="admin-logout-button" onClick={onLogout} data-testid="button-admin-logout">
            <LogOut size={15} /> Sign out
          </button>
        </div>
      </header>
      <div className="admin-dashboard-wrap">
        <div className="admin-dashboard-heading">
          <div>
            <span className="admin-eyebrow">Private workspace</span>
            <h1>Service center overview.</h1>
            <p>Review the public support surface and the systems that power it.</p>
          </div>
          <div className="admin-secured-badge"><ShieldCheck size={16} /> Secured session</div>
        </div>

        <section className="admin-metric-grid" aria-label="System overview">
          {dashboardItems.map(({ icon: Icon, label, value, detail, tone }) => (
            <article className={`admin-metric-card admin-metric-${tone}`} key={label}>
              <div className="admin-metric-icon"><Icon size={18} /></div>
              <span>{label}</span>
              <strong>{value}</strong>
              <small>{detail}</small>
            </article>
          ))}
        </section>

        <div className="admin-content-grid">
          <section className="admin-panel">
            <div className="admin-panel-heading">
              <div><span className="admin-eyebrow">System checks</span><h2>Everything is ready.</h2></div>
              <span className="admin-live-label"><span /> Live</span>
            </div>
            <div className="admin-check-list">
              <div><CheckCircle2 size={17} /><span><b>Public service center</b><small>Landing page and support intake are reachable.</small></span><em>Ready</em></div>
              <div><CheckCircle2 size={17} /><span><b>Market ticker</b><small>Cryptocurrency prices and logos load from CoinGecko.</small></span><em>Ready</em></div>
              <div><CheckCircle2 size={17} /><span><b>Admin session</b><small>Signed, HTTP-only access cookie is active.</small></span><em>Protected</em></div>
            </div>
          </section>

          <section className="admin-panel admin-access-panel">
            <div className="admin-panel-heading">
              <div><span className="admin-eyebrow">Access</span><h2>Authorized audience.</h2></div>
              <Users size={19} />
            </div>
            <p>Use this dashboard for internal owner and investor review. Never share the dashboard password in a support request or public channel.</p>
            <div className="admin-access-list">
              <span><span className="admin-access-dot" /> Owner access</span>
              <span><span className="admin-access-dot" /> Investor access</span>
            </div>
            <div className="admin-session-detail">Session expires automatically for security.</div>
          </section>
        </div>

        <section className="admin-panel admin-requests-panel" aria-labelledby="support-requests-title">
          <div className="admin-panel-heading">
            <div>
              <span className="admin-eyebrow">Support inbox</span>
              <h2 id="support-requests-title">Submitted complaints.</h2>
            </div>
            <span className="admin-request-count">{requests.length} {requests.length === 1 ? "request" : "requests"}</span>
          </div>
          {requestsLoading && (
            <div className="admin-request-state" role="status">
              <span className="admin-inline-spinner" /> Loading complaints…
            </div>
          )}
          {!requestsLoading && requestsError && (
            <p className="admin-request-error" role="alert">{requestsError}</p>
          )}
          {!requestsLoading && !requestsError && requests.length === 0 && (
            <div className="admin-request-state admin-request-empty">
              <Inbox size={20} />
              <span>No complaints have been submitted yet.</span>
            </div>
          )}
          {!requestsLoading && !requestsError && requests.length > 0 && (
            <div className="admin-request-list">
              {requests.map((request) => (
                <article className="admin-request-card" key={request.id}>
                  <div className="admin-request-card-top">
                    <div>
                      <span className="admin-request-service">{request.service}</span>
                      <span className="admin-request-date">{formatRequestDate(request.createdAt)}</span>
                    </div>
                    <span className="admin-request-status">{request.status}</span>
                  </div>
                  <div className="admin-request-meta">
                    <span>Wallet: <b>{request.wallet || "Not selected"}</b></span>
                  </div>
                  <p className="admin-request-complaint">{request.complaint}</p>
                  <button
                    className="admin-copy-button"
                    type="button"
                    onClick={() => void copyComplaint(request)}
                    data-testid={`button-copy-complaint-${request.id}`}
                  >
                    <Copy size={14} />
                    {copiedRequestId === request.id ? "Copied" : "Copy complaint"}
                  </button>
                </article>
              ))}
            </div>
          )}
        </section>

        <footer className="admin-footer">
          <span>ChainCore Service Center · Internal dashboard</span>
          <a href="/">Back to public site <ArrowRight size={13} /></a>
        </footer>
      </div>
    </main>
  );
}

export default function AdminPage() {
  const [session, setSession] = useState<AdminSession | null>(null);
  const [checkingSession, setCheckingSession] = useState(true);

  useEffect(() => {
    let active = true;
    fetch(`${apiBase}/session`, { credentials: "include" })
      .then(async (response) => {
        if (!response.ok) return null;
        return (await response.json()) as AdminSession;
      })
      .then((currentSession) => {
        if (active) {
          setSession(currentSession);
          setCheckingSession(false);
        }
      })
      .catch(() => {
        if (active) setCheckingSession(false);
      });
    return () => {
      active = false;
    };
  }, []);

  async function logout() {
    await fetch(`${apiBase}/logout`, {
      method: "POST",
      credentials: "include",
    }).catch(() => undefined);
    setSession(null);
  }

  if (checkingSession) {
    return <main className="admin-page admin-loading-page"><div className="admin-loading-mark"><span /></div></main>;
  }

  return session ? (
    <AdminDashboard session={session} onLogout={logout} />
  ) : (
    <AdminLogin onAuthenticated={setSession} />
  );
}