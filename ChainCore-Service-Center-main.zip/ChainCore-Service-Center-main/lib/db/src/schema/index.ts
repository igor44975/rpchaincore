import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const supportRequestsTable = pgTable("support_requests", {
  id: serial("id").primaryKey(),
  service: text("service").notNull(),
  wallet: text("wallet"),
  complaint: text("complaint").notNull(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type SupportRequest = typeof supportRequestsTable.$inferSelect;
export type NewSupportRequest = typeof supportRequestsTable.$inferInsert;